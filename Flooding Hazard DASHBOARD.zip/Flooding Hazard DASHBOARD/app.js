// Initialize Google Earth Engine
require(['@google/earthengine'], function(ee) {
    // Initialize Earth Engine
    ee.initialize({
        apiKey: 'YOUR_API_KEY_HERE', // Replace with your actual API key
        onImmediateSuccess: function() {
            console.log('Earth Engine initialized');
            initializeMap();
            loadData();
        },
        onImmediateFailure: function(e) {
            console.error('Error initializing Earth Engine:', e);
        }
    });
});

let map;
const projectPath = 'projects/thermal-shuttle-438007-a4/assets/';

function initializeMap() {
    // Initialize Leaflet map
    map = L.map('map').setView([36.75, 3.06], 10);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Load Earth Engine layers
    loadMapLayers();
}

function loadMapLayers() {
    // Load and add your Earth Engine layers
    const AOI = ee.FeatureCollection(projectPath + 'AOI');
    const rivieres = ee.FeatureCollection(projectPath + 'rivieres_osm');
    const soilRaster = ee.Image(projectPath + 'SoilTypes_1');
    
    // Get map IDs for the layers and add them to the map
    AOI.getMap({ color: 'red' }, function(map) {
        L.tileLayer(map.urlFormat).addTo(map);
    });

    // Add other layers similarly...
}

function loadData() {
    // Load precipitation data and create charts
    const chirpsTable = ee.FeatureCollection('projects/thermal-shuttle-438007-a4/assets/CHIRPS_Monthly_Cleaned');
    
    // Calculate statistics and update indicators
    calculateStatistics(chirpsTable);
    
    // Create charts
    createCharts(chirpsTable);
}

function calculateStatistics(data) {
    // Calculate total, max, and min precipitation
    data.aggregate_stats('precip_mm').evaluate(function(stats) {
        document.getElementById('totalPrecip').textContent = stats.sum.toFixed(0) + ' mm';
        document.getElementById('maxPrecip').textContent = stats.max.toFixed(0) + ' mm';
        document.getElementById('minPrecip').textContent = stats.min.toFixed(0) + ' mm';
    });
}

function createCharts(data) {
    // Create precipitation charts using Chart.js
    createPrecipitationChart();
    createMonthlyChart();
    createTimeSeriesChart();
}

function createPrecipitationChart() {
    const ctx = document.getElementById('precipChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: Array.from({ length: 23 }, (_, i) => 2000 + i),
            datasets: [{
                label: 'Précipitation Annuelle',
                data: [], // Will be populated with actual data
                borderColor: '#1976d2',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Précipitation Annuelle Moyenne (2000-2022)'
                }
            }
        }
    });
}

// Add event listeners for map interactions
map.on('click', function(e) {
    // Handle map clicks and update info panel
    updateInfoPanel(e.latlng);
});

function updateInfoPanel(latlng) {
    // Update info panel with clicked location data
    const info = document.getElementById('info');
    info.innerHTML = `
        <p>Latitude: ${latlng.lat.toFixed(4)}</p>
        <p>Longitude: ${latlng.lng.toFixed(4)}</p>
    `;
    
    // Query Earth Engine data at click location
    queryLocation(latlng);
}

function queryLocation(latlng) {
    // Query Earth Engine layers at click location
    const point = ee.Geometry.Point([latlng.lng, latlng.lat]);
    // Add your queries here...
}

// Initialize the dashboard when the page loads
window.addEventListener('load', function() {
    // Charts will be initialized after Earth Engine is ready
    google.charts.load('current', {'packages':['corechart']});
});
