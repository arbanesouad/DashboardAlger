// Données annuelles de précipitations pour Alger (2000-2022)
const annualPrecipitationData = [
    { year: 2000, precip_mm: 620 },
    { year: 2001, precip_mm: 580 },
    { year: 2002, precip_mm: 750 },
    { year: 2003, precip_mm: 820 },
    { year: 2004, precip_mm: 670 },
    { year: 2005, precip_mm: 590 },
    { year: 2006, precip_mm: 680 },
    { year: 2007, precip_mm: 730 },
    { year: 2008, precip_mm: 640 },
    { year: 2009, precip_mm: 890 },
    { year: 2010, precip_mm: 760 },
    { year: 2011, precip_mm: 710 },
    { year: 2012, precip_mm: 680 },
    { year: 2013, precip_mm: 750 },
    { year: 2014, precip_mm: 820 },
    { year: 2015, precip_mm: 640 },
    { year: 2016, precip_mm: 590 },
    { year: 2017, precip_mm: 630 },
    { year: 2018, precip_mm: 870 },
    { year: 2019, precip_mm: 780 },
    { year: 2020, precip_mm: 650 },
    { year: 2021, precip_mm: 720 },
    { year: 2022, precip_mm: 750 }
];

// Données quinquennales
const quinquennialData = [
    { period: "2000-2004", precip_mm: 600 },
    { period: "2005-2009", precip_mm: 605.8 },
    { period: "2010-2014", precip_mm: 647.2 },
    { period: "2015-2019", precip_mm: 580.6 },
    { period: "2020-2022", precip_mm: 651.7 }
];

// Données mensuelles moyennes (2000-2022)
const monthlyAverageData = [
    { month: "Jan", precip_mm: 86 },
    { month: "Fév", precip_mm: 71 },
    { month: "Mar", precip_mm: 62 },
    { month: "Avr", precip_mm: 58 },
    { month: "Mai", precip_mm: 42 },
    { month: "Juin", precip_mm: 15 },
    { month: "Juil", precip_mm: 4 },
    { month: "Août", precip_mm: 6 },
    { month: "Sept", precip_mm: 32 },
    { month: "Oct", precip_mm: 57 },
    { month: "Nov", precip_mm: 78 },
    { month: "Déc", precip_mm: 89 }
];

// Fonctions de traitement des données
async function loadCSVData(filePath) {
    const response = await fetch(filePath);
    const csvText = await response.text();
    return Papa.parse(csvText, { header: true }).data;
}

// Traiter les données annuelles
async function processAnnualData() {
    const data = await loadCSVData('../data/CHIRPS_Annual_Precipitation_2000_2022.csv');
    return data.map(row => ({
        year: parseInt(row.year),
        precip_mm: parseFloat(row.precip_mm)
    })).sort((a, b) => a.year - b.year);
}

// Traiter les données mensuelles
async function processMonthlyData() {
    const data = await loadCSVData('../data/CHIRPS_Monthly_Cleaned.csv');
    return data.map(row => ({
        year: parseInt(row.year),
        month: parseInt(row.month),
        precip_mm: parseFloat(row.precip_mm)
    })).sort((a, b) => a.year - b.year || a.month - b.month);
}

// Calculer les moyennes mensuelles
function calculateMonthlyAverages(monthlyData) {
    const monthlyAverages = Array(12).fill(0);
    const monthCounts = Array(12).fill(0);
    
    monthlyData.forEach(row => {
        const monthIndex = row.month - 1;
        monthlyAverages[monthIndex] += row.precip_mm;
        monthCounts[monthIndex]++;
    });

    return monthlyAverages.map((sum, index) => ({
        month: index + 1,
        precip_mm: sum / monthCounts[index]
    }));
}

// Calculer les moyennes quinquennales
function calculateQuinquennialAverages(annualData) {
    const periods = [];
    let currentPeriod = Math.floor(annualData[0].year / 5) * 5;
    let currentSum = 0;
    let currentCount = 0;

    annualData.forEach(row => {
        const rowPeriodStart = Math.floor(row.year / 5) * 5;
        if (rowPeriodStart !== currentPeriod && currentCount > 0) {
            periods.push({
                period: `${currentPeriod}-${currentPeriod + 4}`,
                precip_mm: currentSum / currentCount
            });
            currentPeriod = rowPeriodStart;
            currentSum = 0;
            currentCount = 0;
        }
        currentSum += row.precip_mm;
        currentCount++;
    });

    if (currentCount > 0) {
        periods.push({
            period: `${currentPeriod}-${currentPeriod + 4}`,
            precip_mm: currentSum / currentCount
        });
    }

    return periods;
}

// Exporter les données
export {
    loadCSVData,
    processAnnualData,
    processMonthlyData,
    calculateMonthlyAverages,
    calculateQuinquennialAverages
};
