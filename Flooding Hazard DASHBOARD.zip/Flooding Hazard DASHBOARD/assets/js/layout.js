document.addEventListener('DOMContentLoaded', () => {
    const layoutBtns = document.querySelectorAll('.layout-btn');
    const contentWrapper = document.querySelector('.content-wrapper');

    // Set initial layout
    contentWrapper.classList.add('side');

    // Layout toggle handlers
    layoutBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Update buttons
            layoutBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Update layout
            contentWrapper.classList.remove('side', 'bottom');
            contentWrapper.classList.add(btn.dataset.layout);
        });
    });

    // Initialize toggle functionality for charts section
    const chartsSection = document.querySelector('.charts-section');
    const toggleBar = document.querySelector('.charts-toggle-bar');

    if (toggleBar && chartsSection) {
        toggleBar.addEventListener('click', function() {
            chartsSection.classList.toggle('collapsed');
        });
    }
});
