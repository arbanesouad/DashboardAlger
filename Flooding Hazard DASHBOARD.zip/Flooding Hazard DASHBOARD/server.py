from http.server import HTTPServer, SimpleHTTPRequestHandler
import sys
import os

class CORSRequestHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET')
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        return super().end_headers()

    def do_GET(self):
        # Set content types before calling do_GET
        if self.path.endswith('.js'):
            self.send_response(200)
            self.send_header('Content-type', 'application/javascript')
            self.end_headers()
        elif self.path.endswith('.css'):
            self.send_response(200)
            self.send_header('Content-type', 'text/css')
            self.end_headers()
        elif self.path.endswith('.html'):
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
        elif self.path.endswith('.json') or self.path.endswith('.geojson'):
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
        elif self.path.endswith('.tif') or self.path.endswith('.tiff'):
            self.send_response(200)
            self.send_header('Content-type', 'image/tiff')
            self.end_headers()        # Handle root path
        if self.path == '/':
            self.path = '/dashboard-simple.html'
        elif self.path == '/dashboard.css':
            self.path = '/dashboard-simple.css'
            
        return SimpleHTTPRequestHandler.do_GET(self)

port = 8080
print(f"Démarrage du serveur sur le port {port}...")
print(f"Accédez au dashboard via : http://localhost:{port}/dashboard.html")
print("Ou via : http://127.0.0.1:8080/dashboard.html")

try:
    server = HTTPServer(('0.0.0.0', port), CORSRequestHandler)
    print("Serveur démarré avec succès!")
    server.serve_forever()
except Exception as e:
    print(f"Erreur lors du démarrage du serveur : {e}")
    print("Essayez un autre port, par exemple : python server.py 8081")
    sys.exit(1)
